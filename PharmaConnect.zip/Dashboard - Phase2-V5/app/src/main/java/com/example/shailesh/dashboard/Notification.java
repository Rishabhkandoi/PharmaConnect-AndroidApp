package com.example.shailesh.dashboard;

/**
 * Created by isha on 30/3/18.
 */


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by isha on 30/3/18.
 */

public class Notification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

    }
}
