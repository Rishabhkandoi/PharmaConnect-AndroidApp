<?php
  if(isset($_GET['loggedin']))
  {
    if($_GET['loggedin'] == "true")
    {
    }
    else
    {
        header('Location: index.php?loggedin=false');
    }
  }
?>

