<?php
    require '../simple_html_dom.php';
    require 'trending_model.php';
    
    $html = file_get_html('http://www.pharmacytimes.com/');
    $news = array();
    $count=0;
    
    $author = $html->find('div[class=homeItemPub]');
    
    foreach($html->find('div[class=homeItemThumb fl]') as $articles) {
        $links = $articles->find('a');
        $news[$count] = new News();
        $news[$count]->link = "http://www.pharmacytimes.com".$links[0]->href;
        $image = $articles->find('img');
        $news[$count]->heading = $links->title;
        $news[$count]->thumb = $image[0]->src;
        
        $count++;
    }
    
    for($i=0;$i<sizeof($news);$i++) {
        $news[$i]->author = $author[$i]->plaintext;
        $html2 = file_get_html($news[$i]->link);
        $news[$i]->desc = htmlspecialchars_decode($html2->find("meta[name=description]",0)->getAttribute('content'));
    }
    
    header('Content-Type: application/json');
    echo json_encode($news, JSON_PRETTY_PRINT);

?>