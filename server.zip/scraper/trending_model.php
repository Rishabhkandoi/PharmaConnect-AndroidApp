<?php
    class News {
        public $author = "";
        public $heading = "";
        public $thumb = "";
        public $link = "";
        public $desc = "";
    }
?>