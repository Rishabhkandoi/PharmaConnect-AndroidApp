<?php
    class News {
        public $date = "";
        public $heading = "";
        public $thumb = "";
        public $link = "";
        public $desc = "";
    }
?>