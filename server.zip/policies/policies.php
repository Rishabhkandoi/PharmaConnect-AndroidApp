<?php
    require '../simple_html_dom.php';
    require 'policy_model.php';
    header('Content-Type: application/json');
    echo "[\n";
    
    $html = file_get_html('http://www.pci.nic.in/PolicyCirculars/Circulars.aspx');
    $policies = array();
    $count=1;
    
    $table = $html->find('table[id=ctl00_ContentPlaceHolder1_GRDCLGData]');
    
    $size = sizeof($table[0]->find('tr'));
    
    foreach($table[0]->find('tr') as $p) {
        if($p->align == "center")
            continue;
        $policies[$count] = new Policy();
        $desc = $p->find('td[height=20]');
        $date = $p->find('td');
        $link = "http://www.pci.nic.in/".$p->find('a')[0]->href;
        $policies[$count]->desc = $desc[0];
        $policies[$count]->link = $link;
        $policies[$count]->date = $date[2];

        $final = str_replace('"', '', $desc[0]->plaintext);
        $final = str_replace('\n', '', $final);
        $final = str_replace('  ', ' ', $final);
            
        echo "\t{\n";
        echo "\t\t\"date\": \"".$date[2]->plaintext."\",\n";
        echo "\t\t\"desc\": \"".$final."\",\n";
        echo "\t\t\"link\": \"".$link."\"\n";
        
        if($count != $size-1)
            echo "\t},\n";
        else
            echo "\t}\n";
        
        $count++;
    }
    
    echo "]";
    //echo json_encode($policies, JSON_PRETTY_PRINT);

?>