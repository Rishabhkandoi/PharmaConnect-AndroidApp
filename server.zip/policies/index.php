<?php
    require '../simple_html_dom.php';
    require 'policy_model.php';
    
    $html = file_get_html('http://www.pci.nic.in/PolicyCirculars/Circulars.aspx');
    $policies = array();
    
    $table = $html->find('table[id=ctl00_ContentPlaceHolder1_GRDCLGData]');
    echo $table[0];
    
   /* foreach($table->find('tr') as $p) {
        $policies[$count] = new Policy();
        $desc = $p->ChildNode(0);
        echo $desc;
        
        $count++;
    }*/
    
    //header('Content-Type: application/json');
    //echo json_encode($policies, JSON_PRETTY_PRINT);

?>