<?php
    class Policy {
        public $date = "";
        public $link = "";
        public $desc = "";
    }
?>