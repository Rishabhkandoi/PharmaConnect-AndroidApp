<?php
    require '../simple_html_dom.php';
    require 'trending_model.php';
    
    $html = file_get_html('http://www.pharmatimes.com/news');
    $trending = array();
    $count=0;
    
    foreach ($html->find('div[class=article-big-image]') as $articles) {
        $links = $articles->find('a');
        $trending[$count] = new Trending();
        $trending[$count]->link = "http://www.pharmatimes.com/news".$links[0]->href;
        $image = $articles->find('img');
        $trending[$count]->thumb = $image[0]->src;
        
        $contents = $html2->find('div[class=article-content]');
    
        $trending[$count]->desc = $contents->find('p[class=article-lead]');
        
        $trending[$count]->heading = $contents->find('a[class=title-link]');
        
        $count++;
        }
    
    header('Content-Type: application/json');
    echo json_encode($trending, JSON_PRETTY_PRINT);
?>