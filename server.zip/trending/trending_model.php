<?php
    class Trending {
        public $heading = "";
        public $thumb = "";
        public $link = "";
        public $desc = "";
    }
?>