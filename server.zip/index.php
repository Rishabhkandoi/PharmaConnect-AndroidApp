<html>
    <head>
        <title>
            Smart India Hackathon 2018 - Grand Finale
        </title>
    </head>
<body>
    <h1>Smart India Hackathon 2018 - Grand Finale</h1>
    <h2>Kolkata Nodal Centre - GURUNANAK INSTITUTE OF TECHNOLOGY</h2>
    <p>
        This is the web server and disk space for Team H3xl4w of NIIT University, comprising of:
        <ul>
            <li>Isha Pali</li>
            <li>Kumari Renuka</li>
            <li>Shailesh Mohta</li>
            <li>Rishabh Kumar Kandoi</li>
            <li>Abhimanyu Sangitrao</li>
            <li>Harshit Budhraja</li>
        </ul>
    </p>
</body>
</html>